PEP SUPPLIERS GPT WORKING FILES — V10

Use this package as the current handoff set.

WHAT IS APPROVED
1. approved-hero-card-style-reference-gpt.png
   - This is the approved hero/card visual direction.
   - Soft color fill, strong headline, CTA row, trust cards, Domestic/Overseas cards.

2. pep-suppliers-homepage-gpt-v7-colorfill.html
   - Best current HTML working file for layout/color direction.
   - Use as the base for further edits.
   - The logo/header inside this HTML is NOT final.

WHAT IS NOT APPROVED
Do not use the v9 SVG/PNG logo.
Do not use the CSS-only logo from v8.
Those drifted from the approved logo direction.

LOGO STATUS
The logo is still unresolved.
The approved logo direction is:
- Large syringe graphic on the left
- Large colorful “Pep Suppliers” wordmark
- Three underline/accent bars
- Tagline exactly: ALL-IN-ONE PEPTIDE SOURCE
- No Rx / Peps / Vitamins
- No Dark Mode
- No Buy Me a Coffee

REFERENCE FILES
approved-header-logo-reference-gpt.png
header-reference-gpt-v4-uncropped.png
logo-region-reference-gpt-v4-uncropped.png

These are visual references only until a final clean logo/header asset is produced.

NEXT BUILDER INSTRUCTION
Use pep-suppliers-homepage-gpt-v7-colorfill.html as the current HTML base.
Match approved-hero-card-style-reference-gpt.png for page style.
Do not use the rejected v9 logo or CSS-only logo.
Treat the final logo/header asset as unresolved until Jason approves it visually.
