PEP SUPPLIERS GPT V13 — APPROVED HEADER RESTORE

This package restores the earlier approved visual direction Jason liked:
- large colorful Pep Suppliers logo/header
- no Rx / Peps / Vitamins
- tagline: ALL-IN-ONE PEPTIDE SOURCE
- 2x2 nav pills
- approved hero/card color-fill style

Files:
- pep-suppliers-homepage-gpt-v13-approved-header.html: full HTML
- pep-suppliers-approved-logo-gpt-v13.png: cropped from the approved no-Rx/no-Peps mockup, with generous width
- pep-suppliers-approved-header-reference-gpt-v13.png: full header reference crop

Note:
This restores the earlier liked mockup approach instead of the v12 temporary text lockup.
